<?php
class controladorPlantilla {
    public function ctrtraerplantilla() {
        include 'vista/plantilla.php';
    }
}
